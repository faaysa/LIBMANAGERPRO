using System;
using System.Windows.Forms;

namespace LibraryManagerProCleanV11
{
    /// <summary>
    /// Application entry point. Sets up high-DPI + visual styles and launches the main form.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Standard WinForms Main method with STA threading model for UI components.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Enable OS theming and high-DPI handling BEFORE the first control is created.
            Application.EnableVisualStyles();
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.SetCompatibleTextRenderingDefault(false);

            // Launch the primary UI.
            Application.Run(new LibraryManagerProCleanV11.Forms.MainForm());
        }
    }
}
