using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using LibraryManagerProCleanV11.Models;

namespace LibraryManagerProCleanV11.Services
{
    /// <summary>
    /// File I/O for JSON persistence and CSV export. Kept intentionally simple.
    /// </summary>
    public static class DataStore
    {
        private static readonly JsonSerializerOptions _json = new JsonSerializerOptions { WriteIndented = true };

        /// <summary>
        /// Write the entire <see cref="LibraryData"/> graph to disk as UTF-8 JSON.
        /// Idempotent: creates the directory if needed.
        /// </summary>
        public static void SaveData(LibraryData data, string path)
        {
            EnsureDir(path);
            var json = JsonSerializer.Serialize(data ?? new LibraryData(), _json);
            File.WriteAllText(path, json, Encoding.UTF8);
        }

        /// <summary>
        /// Load the entire <see cref="LibraryData"/> graph from disk.
        /// Returns an empty model if the file is missing or invalid.
        /// </summary>
        public static LibraryData LoadData(string path)
        {
            try
            {
                if (!File.Exists(path)) return new LibraryData();
                var json = File.ReadAllText(path, Encoding.UTF8);
                return JsonSerializer.Deserialize<LibraryData>(json, _json) ?? new LibraryData();
            }
            catch
            {
                // Defensive: never throw from load; return a safe empty object instead.
                return new LibraryData();
            }
        }

        /// <summary>
        /// Export the supplied list of books to a CSV file (UTF-8).
        /// We quote fields and double-quote any internal quotes.
        /// </summary>
        public static void ExportCsv(List<Book> books, string path)
        {
            EnsureDir(path);
            using var sw = new StreamWriter(path, false, Encoding.UTF8);

            // Header row for easy import into spreadsheets.
            sw.WriteLine("Isbn,Title,Author,Genre,Year,Quantity,AddedOn,CheckedOut");

            if (books == null) return;

            foreach (var b in books)
            {
                // Compose one row using CSV-safe quoted fields.
                sw.WriteLine(string.Join(",",
                    Q(b?.Isbn ?? string.Empty),
                    Q(b?.Title ?? string.Empty),
                    Q(b?.Author ?? string.Empty),
                    Q(b?.Genre ?? string.Empty),
                    (b?.Year ?? 0).ToString(),
                    (b?.Quantity ?? 0).ToString(),
                    Q((b?.AddedOn ?? DateTime.MinValue).ToString("u")),
                    (b?.CheckedOut ?? false) ? "true" : "false"
                ));
            }
        }

        /// <summary>
        /// Ensure the target directory exists for the supplied path.
        /// </summary>
        private static void EnsureDir(string path)
        {
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);
        }

        /// <summary>
        /// Quote a field for CSV: escape <c>"</c> as <c>""</c> and wrap value in quotes.
        /// </summary>
        private static string Q(string s)
        {
            if (s == null) s = string.Empty;
            s = s.Replace("\"", "\"\"");       // double any internal quotes
            return """ + s + """;            // wrap field in quotes
        }
    }
}
