using System;
using System.Drawing;
using System.Windows.Forms;
using LibraryManagerProCleanV11.Models;

namespace LibraryManagerProCleanV11.Forms
{
    /// <summary>
    /// Modal dialog for adding or editing a <see cref="Member"/>.
    /// </summary>
    public class AddEditMemberDialog : Form
    {
        /// <summary>Result of the dialog on success; null if canceled.</summary>
        public Member? ResultMember { get; private set; }

        private readonly Member? _original;

        // Editor controls
        private TextBox _name = new TextBox();
        private TextBox _email = new TextBox();
        private TextBox _phone = new TextBox();
        private DateTimePicker _joined = new DateTimePicker();
        private Button _ok = new Button();
        private Button _cancel = new Button();
        private ErrorProvider _err = new ErrorProvider();

        /// <summary>Create dialog; if <paramref name="existing"/> is supplied, pre-fill fields.</summary>
        public AddEditMemberDialog(Member? existing = null)
        {
            _original = existing;
            Text = existing == null ? "Add Member" : "Edit Member";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(500, 300);
            Init();

            if (existing != null)
            {
                _name.Text = existing.FullName;
                _email.Text = existing.Email;
                _phone.Text = existing.Phone;
                _joined.Value = existing.JoinedOn;
            }
        }

        /// <summary>Initialize layout and wire up the OK/Cancel buttons.</summary>
        private void Init()
        {
            _err.ContainerControl = this;

            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 5, Padding = new Padding(12) };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));

            _joined.Format = DateTimePickerFormat.Short;

            void Row(string label, Control c, int r)
            {
                t.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, r);
                c.Dock = DockStyle.Fill; t.Controls.Add(c, 1, r);
            }

            Row("Full Name:", _name, 0);
            Row("Email:", _email, 1);
            Row("Phone:", _phone, 2);
            Row("Joined On:", _joined, 3);

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            _ok.Text = "OK"; _ok.Click += ValidateAndFinish;
            _cancel.Text = "Cancel"; _cancel.Click += (s,e)=>Close();
            buttons.Controls.Add(_ok); buttons.Controls.Add(_cancel);
            t.Controls.Add(buttons, 1, 4);

            Controls.Add(t);
        }

        /// <summary>
        /// Validate required fields and produce a <see cref="Member"/> for the caller.
        /// </summary>
        private void ValidateAndFinish(object? sender, EventArgs e)
        {
            _err.Clear();
            bool ok = true;

            // Required: at least a name. (Email/phone optional for this demo.)
            if (string.IsNullOrWhiteSpace(_name.Text)) { _err.SetError(_name, "Name is required."); ok = false; }
            if (!ok) return;

            ResultMember = new Member
            {
                Id = _original?.Id ?? Guid.NewGuid().ToString("N"),
                FullName = _name.Text.Trim(),
                Email = _email.Text.Trim(),
                Phone = _phone.Text.Trim(),
                JoinedOn = _joined.Value
            };

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
