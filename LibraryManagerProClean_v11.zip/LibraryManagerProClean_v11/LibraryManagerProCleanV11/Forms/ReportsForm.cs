using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using LibraryManagerProCleanV11.Models;

namespace LibraryManagerProCleanV11.Forms
{
    /// <summary>
    /// Lightweight reporting surface to summarize books by genre.
    /// </summary>
    public class ReportsForm : Form
    {
        private readonly List<Book> _books;
        private DataGridView _grid = new DataGridView();
        private Label _lbl = new Label();

        /// <summary>Create the report for the provided list of books.</summary>
        public ReportsForm(List<Book> books)
        {
            _books = books;
            Text = "Reports";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(600, 420);
            Init();
            Rebuild();
        }

        /// <summary>Build one grid + one status label layout.</summary>
        private void Init()
        {
            _grid.Dock = DockStyle.Fill; _grid.ReadOnly = true;
            _grid.AllowUserToAddRows = false; _grid.AllowUserToDeleteRows = false;
            _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            _lbl.Dock = DockStyle.Top; _lbl.Height = 40;
            _lbl.TextAlign = ContentAlignment.MiddleLeft; _lbl.Padding = new Padding(12,8,12,8);

            Controls.Add(_grid);
            Controls.Add(_lbl);
        }

        /// <summary>Compute rollups and display them in the grid and label.</summary>
        private void Rebuild()
        {
            var byGenre = _books.GroupBy(b => b.Genre).Select(g => new {
                Genre = g.Key,
                Count = g.Count(),
                CheckedOut = g.Count(b => b.CheckedOut)
            }).OrderByDescending(x => x.Count).ToList();

            _grid.DataSource = byGenre;

            int total = _books.Count;
            int totalOut = _books.Count(b => b.CheckedOut);
            _lbl.Text = $"Total books: {total}   •   Checked out: {totalOut}   •   Available: {total - totalOut}";
        }
    }
}
