using System.Drawing;
using System.Windows.Forms;

namespace LibraryManagerProCleanV11.Forms
{
    /// <summary>
    /// Minimal About dialog with app name and a one-liner.
    /// </summary>
    public class AboutForm : Form
    {
        /// <summary>Constructs the About dialog UI.</summary>
        public AboutForm()
        {
            Text = "About";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(420, 240);

            var lbl = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "LibraryManagerProCleanV11\nWinForms (.NET 8) demo\nBooks • Members • Loans"
            };

            var btn = new Button { Text = "OK", Dock = DockStyle.Bottom, Height = 40 };
            btn.Click += (s, e) => Close();

            Controls.Add(lbl);
            Controls.Add(btn);
        }
    }
}
