using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using LibraryManagerProCleanV11.Models;
using LibraryManagerProCleanV11.Services;

namespace LibraryManagerProCleanV11.Forms
{
    /// <summary>
    /// Primary application window. Hosts three tabs (Books, Members, Loans),
    /// a shared search box, and toolbar actions for CRUD + Issue/Return.
    /// </summary>
    public class MainForm : Form
    {
        // ----------- App state ------------
        private LibraryData _data = new LibraryData();
        private AppSettings _settings = new AppSettings();

        // ----------- UI surface -----------
        private TabControl _tabs = new TabControl();
        private TabPage _tabBooks = new TabPage("Books");
        private TabPage _tabMembers = new TabPage("Members");
        private TabPage _tabLoans = new TabPage("Loans");

        private DataGridView _gridBooks = new DataGridView();
        private DataGridView _gridMembers = new DataGridView();
        private DataGridView _gridLoans = new DataGridView();

        private TextBox _txtSearch = new TextBox();
        private ToolStrip _tool = new ToolStrip();
        private StatusStrip _status = new StatusStrip();
        private ToolStripStatusLabel _statusLabel = new ToolStripStatusLabel();

        private string _currentFile => _settings.DataPath;

        /// <summary>
        /// Projection used to populate the Loans grid with friendly names
        /// while retaining the underlying loan Id for selection.
        /// </summary>
        private class LoanView
        {
            public string Id { get; set; } = string.Empty;
            public string Member { get; set; } = string.Empty;
            public string Book { get; set; } = string.Empty;
            public string Isbn { get; set; } = string.Empty;
            public DateTime LoanDate { get; set; }
            public DateTime DueDate { get; set; }
            public DateTime? ReturnedDate { get; set; }
            public string Status { get; set; } = string.Empty;
        }

        /// <summary>Construct the main window and attempt to load persisted data.</summary>
        public MainForm()
        {
            Text = "LibraryManagerProCleanV11";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1100, 700);

            InitializeUi();
            AttemptInitialLoad();
        }

        /// <summary>Build out menu, toolbar, tabs, status bar; wire keyboard shortcuts.</summary>
        private void InitializeUi()
        {
            // ----- Menu -----
            var menu = new MenuStrip();
            var mFile = new ToolStripMenuItem("File");
            mFile.DropDownItems.Add(new ToolStripMenuItem("New", null, (s,e)=>NewFile()));
            mFile.DropDownItems.Add(new ToolStripMenuItem("Open...", null, (s,e)=>OpenFile()));
            mFile.DropDownItems.Add(new ToolStripMenuItem("Save", null, (s,e)=>SaveFile()));
            mFile.DropDownItems.Add(new ToolStripSeparator());
            mFile.DropDownItems.Add(new ToolStripMenuItem("Export Books CSV...", null, (s,e)=>ExportCsv()));
            mFile.DropDownItems.Add(new ToolStripSeparator());
            mFile.DropDownItems.Add(new ToolStripMenuItem("Exit", null, (s,e)=>Close()));

            var mView = new ToolStripMenuItem("View");
            mView.DropDownItems.Add(new ToolStripMenuItem("Reports", null, (s,e)=> new ReportsForm(_data.Books.ToList()).ShowDialog()));
            mView.DropDownItems.Add(new ToolStripMenuItem("Settings", null, (s,e)=> OpenSettings()));
            mView.DropDownItems.Add(new ToolStripMenuItem("About", null, (s,e)=> new AboutForm().ShowDialog()));

            menu.Items.Add(mFile); menu.Items.Add(mView);
            MainMenuStrip = menu; Controls.Add(menu);

            // ----- Toolbar -----
            _tool.GripStyle = ToolStripGripStyle.Hidden;
            _tool.Items.Add(new ToolStripLabel("Books:"));
            _tool.Items.Add(new ToolStripButton("Add", null, (s,e)=>AddBook()));
            _tool.Items.Add(new ToolStripButton("Edit", null, (s,e)=>EditSelectedBook()));
            _tool.Items.Add(new ToolStripButton("Delete", null, (s,e)=>DeleteSelectedBook()));
            _tool.Items.Add(new ToolStripSeparator());
            _tool.Items.Add(new ToolStripLabel("Members:"));
            _tool.Items.Add(new ToolStripButton("Add", null, (s,e)=>AddMember()));
            _tool.Items.Add(new ToolStripButton("Edit", null, (s,e)=>EditSelectedMember()));
            _tool.Items.Add(new ToolStripButton("Delete", null, (s,e)=>DeleteSelectedMember()));
            _tool.Items.Add(new ToolStripSeparator());
            _tool.Items.Add(new ToolStripLabel("Loans:"));
            _tool.Items.Add(new ToolStripButton("Issue", null, (s,e)=>IssueLoan()));
            _tool.Items.Add(new ToolStripButton("Return", null, (s,e)=>ReturnSelectedLoan()));
            _tool.Items.Add(new ToolStripButton("Delete", null, (s,e)=>DeleteSelectedLoan()));
            _tool.Items.Add(new ToolStripSeparator());
            _tool.Items.Add(new ToolStripLabel("Search:"));
            var host = new ToolStripControlHost(_txtSearch) { AutoSize = false, Width = 260 };
            _tool.Items.Add(host);

            // Quick navigation buttons: clear any filter and switch to the requested tab.
            _tool.Items.Add(new ToolStripButton("Books", null, (s,e)=>{ _txtSearch.Clear(); _tabs.SelectedTab = _tabBooks; RefreshViews(); }));
            _tool.Items.Add(new ToolStripButton("Members", null, (s,e)=>{ _txtSearch.Clear(); _tabs.SelectedTab = _tabMembers; RefreshViews(); }));
            _tool.Items.Add(new ToolStripButton("Loans", null, (s,e)=>{ _txtSearch.Clear(); _tabs.SelectedTab = _tabLoans; RefreshViews(); }));
            _tool.Dock = DockStyle.Top; Controls.Add(_tool);
            _txtSearch.TextChanged += (s,e)=>RefreshViews();  // live filtering

            // ----- Tabs + grids -----
            _tabs.Dock = DockStyle.Fill;
            _tabBooks.Controls.Add(_gridBooks);
            _tabMembers.Controls.Add(_gridMembers);
            _tabLoans.Controls.Add(_gridLoans);
            _tabs.TabPages.AddRange(new TabPage[] { _tabBooks, _tabMembers, _tabLoans });
            Controls.Add(_tabs);

            ConfigureGrid(_gridBooks);
            ConfigureGrid(_gridMembers);
            ConfigureGrid(_gridLoans);

            // ----- Status -----
            _statusLabel.Text = "Ready";
            _status.Items.Add(_statusLabel);
            _status.Dock = DockStyle.Bottom;
            Controls.Add(_status);

            // ----- Keyboard shortcuts -----
            KeyPreview = true;
            KeyDown += (s,e)=>{
                if (e.Control && e.KeyCode == Keys.N) { AddBook(); e.Handled = true; }
                if (e.Control && e.KeyCode == Keys.S) { SaveFile(); e.Handled = true; }
                if (e.KeyCode == Keys.Delete)
                {
                    if (_tabs.SelectedTab == _tabBooks) DeleteSelectedBook();
                    else if (_tabs.SelectedTab == _tabMembers) DeleteSelectedMember();
                    else if (_tabs.SelectedTab == _tabLoans) DeleteSelectedLoan();
                    e.Handled = true;
                }
            };
        }

        /// <summary>Apply consistent grid settings across all tabs.</summary>
        private void ConfigureGrid(DataGridView g)
        {
            g.Dock = DockStyle.Fill;
            g.ReadOnly = true;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.AutoGenerateColumns = true; // always auto-generate columns from bound objects
            g.MultiSelect = false;
        }

        // --------------------- File operations ---------------------

        /// <summary>Attempt to load the last-used JSON file; else start with empty data.</summary>
        private void AttemptInitialLoad()
        {
            try
            {
                if (File.Exists(_currentFile))
                {
                    _data = DataStore.LoadData(_currentFile);
                    RefreshViews();  // rebind grids
                    SetStatus("Loaded data from " + _currentFile);
                }
                else
                {
                    _data = new LibraryData();
                    SetStatus("No data file yet. Start by adding books or members.");
                }
            }
            catch (Exception ex)
            {
                _data = new LibraryData();
                SetStatus("Load failed: " + ex.Message);
            }
        }

        /// <summary>Clear all lists and start a new in-memory library.</summary>
        private void NewFile()
        {
            _data = new LibraryData();
            RefreshViews();
            SetStatus("Started new, empty library.");
        }

        /// <summary>Prompt the user to choose a JSON file; load it if valid.</summary>
        private void OpenFile()
        {
            using var ofd = new OpenFileDialog {
                Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*",
                FileName = Path.GetFileName(_currentFile),
                InitialDirectory = Path.GetDirectoryName(_currentFile)
            };
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                _data = DataStore.LoadData(ofd.FileName);
                _settings.DataPath = ofd.FileName;  // remember this path
                RefreshViews();
                SetStatus("Opened: " + ofd.FileName);
            }
        }

        /// <summary>Persist current data to the configured JSON path.</summary>
        private void SaveFile()
        {
            try { DataStore.SaveData(_data, _currentFile); SetStatus("Saved: " + _currentFile); }
            catch (Exception ex) { SetStatus("Save failed: " + ex.Message); }
        }

        /// <summary>Export the book catalog to CSV for spreadsheets.</summary>
        private void ExportCsv()
        {
            using var sfd = new SaveFileDialog {
                Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*",
                FileName = "library_books.csv"
            };
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try { DataStore.ExportCsv(_data.Books, sfd.FileName); SetStatus("Exported CSV to " + sfd.FileName); }
                catch (Exception ex) { SetStatus("CSV export failed: " + ex.Message); }
            }
        }

        /// <summary>Open the Settings dialog and apply changes.</summary>
        private void OpenSettings()
        {
            using var f = new SettingsForm(_settings);
            if (f.ShowDialog() == DialogResult.OK)
            {
                SetStatus("Settings updated. Autosave=" + _settings.AutoSave + ". Path=" + _settings.DataPath);
                if (_settings.AutoSave) SaveFile();
            }
        }

        // --------------------- Books: Add/Edit/Delete ---------------------

        /// <summary>
        /// Create a new <see cref="Book"/> via dialog, ensure ISBN uniqueness,
        /// then clear any search filter, switch to the Books tab, and refresh.
        /// </summary>
        private void AddBook()
        {
            using var dlg = new AddEditDialog();
            if (dlg.ShowDialog() == DialogResult.OK && dlg.ResultBook != null)
            {
                // Guard: ISBN must be unique to avoid ambiguous edits and loans.
                if (_data.Books.Any(b => b.Isbn.Equals(dlg.ResultBook.Isbn, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("A book with this ISBN already exists.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _data.Books.Add(dlg.ResultBook);  // in-memory add

                // Make the result visible: remove filters and show the Books tab.
                _txtSearch.Clear();
                _tabs.SelectedTab = _tabBooks;
                RefreshViews();

                SetStatus("Book added.");
                MaybeAutosave();
            }
        }

        /// <summary>Edit the currently selected book in-place; re-check ISBN uniqueness on change.</summary>
        private void EditSelectedBook()
        {
            var b = GetSelectedBook();
            if (b == null) return;

            // Work on a copy to avoid mutating the grid selection in case of cancel.
            using var dlg = new AddEditDialog(new Book {
                Isbn = b.Isbn, Title = b.Title, Author = b.Author, Genre = b.Genre,
                Year = b.Year, Quantity = b.Quantity, AddedOn = b.AddedOn, CheckedOut = b.CheckedOut
            });
            if (dlg.ShowDialog() == DialogResult.OK && dlg.ResultBook != null)
            {
                // If ISBN changed, ensure it doesn't collide with another book.
                if (!dlg.ResultBook.Isbn.Equals(b.Isbn, StringComparison.OrdinalIgnoreCase) &&
                    _data.Books.Any(x => x.Isbn.Equals(dlg.ResultBook.Isbn, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("Another book already uses that ISBN.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Commit changes
                b.Isbn = dlg.ResultBook.Isbn;
                b.Title = dlg.ResultBook.Title;
                b.Author = dlg.ResultBook.Author;
                b.Genre = dlg.ResultBook.Genre;
                b.Year = dlg.ResultBook.Year;
                b.Quantity = dlg.ResultBook.Quantity;
                b.AddedOn = dlg.ResultBook.AddedOn;
                b.CheckedOut = dlg.ResultBook.CheckedOut;

                RefreshViews();
                SetStatus("Book updated.");
                MaybeAutosave();
            }
        }

        /// <summary>Delete the selected book if there are no active loans referencing it.</summary>
        private void DeleteSelectedBook()
        {
            var b = GetSelectedBook();
            if (b == null) return;

            // Disallow deletion if any active (not yet returned) loan references this ISBN.
            if (_data.Loans.Any(l => l.Isbn == b.Isbn && !l.ReturnedDate.HasValue))
            {
                MessageBox.Show("Cannot delete a book with active loans.", "In Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var confirm = MessageBox.Show("Delete '" + b.Title + "'?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                _data.Books.Remove(b);
                RefreshViews();
                SetStatus("Book deleted.");
                MaybeAutosave();
            }
        }

        /// <summary>Utility to retrieve the selected <see cref="Book"/> from the grid, if any.</summary>
        private Book? GetSelectedBook()
        {
            if (_gridBooks.CurrentRow?.DataBoundItem is Book b) return b;
            return null;
        }

        // --------------------- Members: Add/Edit/Delete ---------------------

        /// <summary>
        /// Create a new <see cref="Member"/> via dialog, then clear search,
        /// switch to the Members tab, and refresh so the row is visible.
        /// </summary>
        private void AddMember()
        {
            using var dlg = new AddEditMemberDialog();
            if (dlg.ShowDialog() == DialogResult.OK && dlg.ResultMember != null)
            {
                _data.Members.Add(dlg.ResultMember);

                _txtSearch.Clear();            // ensure no filter hides the new row
                _tabs.SelectedTab = _tabMembers;
                RefreshViews();

                SetStatus("Member added.");
                MaybeAutosave();
            }
        }

        /// <summary>Edit the currently selected member in-place.</summary>
        private void EditSelectedMember()
        {
            var m = GetSelectedMember();
            if (m == null) return;

            using var dlg = new AddEditMemberDialog(new Member {
                Id = m.Id, FullName = m.FullName, Email = m.Email, Phone = m.Phone, JoinedOn = m.JoinedOn
            });
            if (dlg.ShowDialog() == DialogResult.OK && dlg.ResultMember != null)
            {
                m.FullName = dlg.ResultMember.FullName;
                m.Email = dlg.ResultMember.Email;
                m.Phone = dlg.ResultMember.Phone;
                m.JoinedOn = dlg.ResultMember.JoinedOn;

                RefreshViews();
                SetStatus("Member updated.");
                MaybeAutosave();
            }
        }

        /// <summary>Delete the selected member unless they have an active loan.</summary>
        private void DeleteSelectedMember()
        {
            var m = GetSelectedMember();
            if (m == null) return;

            if (_data.Loans.Any(l => l.MemberId == m.Id && !l.ReturnedDate.HasValue))
            {
                MessageBox.Show("Cannot delete a member with active loans.", "In Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var confirm = MessageBox.Show("Delete member '" + m.FullName + "'?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                _data.Members.Remove(m);
                RefreshViews();
                SetStatus("Member deleted.");
                MaybeAutosave();
            }
        }

        /// <summary>Utility to retrieve the selected <see cref="Member"/> from the grid, if any.</summary>
        private Member? GetSelectedMember()
        {
            if (_gridMembers.CurrentRow?.DataBoundItem is Member m) return m;
            return null;
        }

        // --------------------- Loans: Issue/Return/Delete ---------------------

        /// <summary>
        /// Issue a new loan if at least one member and one book exist,
        /// ensuring there is at least one available copy.
        /// </summary>
        private void IssueLoan()
        {
            if (_data.Members.Count == 0 || _data.Books.Count == 0)
            {
                MessageBox.Show("Add at least one member and one book first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var dlg = new IssueLoanDialog(_data.Members, _data.Books, _data.Loans);
            if (dlg.ShowDialog() == DialogResult.OK && dlg.ResultLoan != null)
            {
                _data.Loans.Add(dlg.ResultLoan);

                // Update the convenience CheckedOut flag on the book.
                var b = _data.Books.FirstOrDefault(x => x.Isbn == dlg.ResultLoan.Isbn);
                if (b != null)
                    b.CheckedOut = _data.Loans.Any(l => l.Isbn == b.Isbn && !l.ReturnedDate.HasValue);

                RefreshViews();
                SetStatus("Loan issued.");
                MaybeAutosave();
            }
        }

        /// <summary>Mark the selected loan as returned and recompute book state.</summary>
        private void ReturnSelectedLoan()
        {
            var lv = _gridLoans.CurrentRow?.DataBoundItem as LoanView;
            if (lv == null) return;

            var l = _data.Loans.FirstOrDefault(x => x.Id == lv.Id);
            if (l == null) return;

            if (l.ReturnedDate.HasValue)
            {
                MessageBox.Show("This loan is already returned.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            l.ReturnedDate = DateTime.Now;  // mark returned

            var b = _data.Books.FirstOrDefault(x => x.Isbn == l.Isbn);
            if (b != null)
                b.CheckedOut = _data.Loans.Any(x => x.Isbn == b.Isbn && !x.ReturnedDate.HasValue);

            RefreshViews();
            SetStatus("Loan returned.");
            MaybeAutosave();
        }

        /// <summary>Delete the selected loan record (useful for cleanup of test data).</summary>
        private void DeleteSelectedLoan()
        {
            var lv = _gridLoans.CurrentRow?.DataBoundItem as LoanView;
            if (lv == null) return;

            var l = _data.Loans.FirstOrDefault(x => x.Id == lv.Id);
            if (l == null) return;

            var confirm = MessageBox.Show("Delete this loan record?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                _data.Loans.Remove(l);

                var b = _data.Books.FirstOrDefault(x => x.Isbn == l.Isbn);
                if (b != null)
                    b.CheckedOut = _data.Loans.Any(x => x.Isbn == b.Isbn && !x.ReturnedDate.HasValue);

                RefreshViews();
                SetStatus("Loan deleted.");
                MaybeAutosave();
            }
        }

        // --------------------- Binding / Utilities ---------------------

        /// <summary>
        /// Apply the current search filter and rebind all three grids.
        /// We project loans into <see cref="LoanView"/> so the grid shows names, not ids.
        /// </summary>
        private void RefreshViews()
        {
            var term = (_txtSearch.Text ?? string.Empty).Trim().ToLowerInvariant();

            // Filter books by Title/Author/ISBN
            var booksView = string.IsNullOrEmpty(term) ? _data.Books.ToList() :
                _data.Books.Where(b => (b.Title ?? string.Empty).ToLowerInvariant().Contains(term) ||
                                       (b.Author ?? string.Empty).ToLowerInvariant().Contains(term) ||
                                       (b.Isbn ?? string.Empty).ToLowerInvariant().Contains(term)).ToList();
            Bind(_gridBooks, booksView);

            // Filter members by Name/Email/Phone
            var membersView = string.IsNullOrEmpty(term) ? _data.Members.ToList() :
                _data.Members.Where(m => (m.FullName ?? string.Empty).ToLowerInvariant().Contains(term) ||
                                         (m.Email ?? string.Empty).ToLowerInvariant().Contains(term) ||
                                         (m.Phone ?? string.Empty).ToLowerInvariant().Contains(term)).ToList();
            Bind(_gridMembers, membersView);

            // Project loans to a friendly view model (member/book names)
            var loansView = _data.Loans.Select(l => new LoanView {
                Id = l.Id,
                Member = _data.Members.FirstOrDefault(m => m.Id == l.MemberId)?.FullName ?? "(deleted)",
                Book = _data.Books.FirstOrDefault(b => b.Isbn == l.Isbn)?.Title ?? "(deleted)",
                Isbn = l.Isbn,
                LoanDate = l.LoanDate,
                DueDate = l.DueDate,
                ReturnedDate = l.ReturnedDate,
                Status = l.ReturnedDate.HasValue ? "Returned" : (DateTime.Now > l.DueDate ? "Overdue" : "On Loan")
            }).ToList();

            // Optional text filter for loans too
            if (!string.IsNullOrEmpty(term))
            {
                loansView = loansView.Where(v =>
                    (v.Member ?? string.Empty).ToLowerInvariant().Contains(term) ||
                    (v.Book ?? string.Empty).ToLowerInvariant().Contains(term) ||
                    (v.Isbn ?? string.Empty).ToLowerInvariant().Contains(term)).ToList();
            }

            Bind(_gridLoans, loansView);

            // Update footer with quick counts for sanity.
            _statusLabel.Text = "Books: " + _data.Books.Count + "  •  Members: " + _data.Members.Count + "  •  Loans: " + _data.Loans.Count;
        }

        /// <summary>Helper: rebind a DataGridView to a new data source.</summary>
        private void Bind(DataGridView g, object data)
        {
            g.DataSource = null;  // reset binding
            g.DataSource = data;  // apply new list
        }

        /// <summary>Persist to disk if autosave is enabled. Swallows exceptions for UX.</summary>
        private void MaybeAutosave()
        {
            if (_settings.AutoSave)
            {
                try { SaveFile(); } catch { /* ignore */ }
            }
        }

        /// <summary>Update the status bar with the latest operation.</summary>
        private void SetStatus(string msg) => _statusLabel.Text = msg;
    }
}
