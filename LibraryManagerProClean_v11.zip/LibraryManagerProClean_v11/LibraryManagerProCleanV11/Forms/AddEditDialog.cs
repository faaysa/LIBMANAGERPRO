using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using LibraryManagerProCleanV11.Models;

namespace LibraryManagerProCleanV11.Forms
{
    /// <summary>
    /// Modal dialog for creating or editing a <see cref="Book"/>.
    /// Validates required fields and returns a Book via <see cref="ResultBook"/> when OK is pressed.
    /// </summary>
    public class AddEditDialog : Form
    {
        /// <summary>Result of the dialog on success; null if canceled.</summary>
        public Book? ResultBook { get; private set; }

        private readonly Book? _original;

        // Editor controls
        private TextBox _isbn = new TextBox();
        private TextBox _title = new TextBox();
        private TextBox _author = new TextBox();
        private ComboBox _genre = new ComboBox();
        private NumericUpDown _year = new NumericUpDown();
        private NumericUpDown _qty = new NumericUpDown();
        private DateTimePicker _added = new DateTimePicker();
        private CheckBox _out = new CheckBox();
        private Button _ok = new Button();
        private Button _cancel = new Button();
        private ErrorProvider _err = new ErrorProvider();

        private readonly string[] _genres = new[] { "General", "Fiction", "Sci-Fi", "Fantasy", "History", "Biography", "Children", "Education", "Mystery" };

        /// <summary>Create the dialog, optionally pre-populating fields from an existing <see cref="Book"/>.</summary>
        public AddEditDialog(Book? existing = null)
        {
            _original = existing;
            Text = existing == null ? "Add Book" : "Edit Book";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(600, 420);
            Init();

            // If editing, hydrate the controls with the existing object's values.
            if (existing != null)
            {
                _isbn.Text = existing.Isbn;
                _title.Text = existing.Title;
                _author.Text = existing.Author;
                _genre.SelectedItem = _genres.FirstOrDefault(g => g == existing.Genre) ?? "General";
                _year.Value = Math.Max(_year.Minimum, Math.Min(_year.Maximum, existing.Year));
                _qty.Value = Math.Max(_qty.Minimum, Math.Min(_qty.Maximum, existing.Quantity));
                _added.Value = existing.AddedOn;
                _out.Checked = existing.CheckedOut;
            }
        }

        /// <summary>Build out controls and layout, and wire up events.</summary>
        private void Init()
        {
            _err.ContainerControl = this;

            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 9, Padding = new Padding(12) };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));

            _genre.DropDownStyle = ComboBoxStyle.DropDownList;
            _genre.Items.AddRange(_genres);
            _genre.SelectedIndex = 0;

            _year.Minimum = 1450; _year.Maximum = DateTime.Now.Year + 1; _year.Value = DateTime.Now.Year;
            _qty.Minimum = 0; _qty.Maximum = 1000; _qty.Value = 1;
            _added.Format = DateTimePickerFormat.Short;

            _ok.Text = "OK"; _ok.Click += ValidateAndFinish;   // OK triggers validation and constructs ResultBook
            _cancel.Text = "Cancel"; _cancel.Click += (s,e)=>Close();

            // Helper to add rows with labels
            void Row(string label, Control c, int r)
            {
                t.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, r);
                c.Dock = DockStyle.Fill; t.Controls.Add(c, 1, r);
            }

            Row("ISBN:", _isbn, 0);
            Row("Title:", _title, 1);
            Row("Author:", _author, 2);
            Row("Genre:", _genre, 3);
            Row("Year:", _year, 4);
            Row("Quantity:", _qty, 5);
            Row("Added On:", _added, 6);
            Row("Checked Out:", _out, 7);

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            buttons.Controls.Add(_ok); buttons.Controls.Add(_cancel);
            t.Controls.Add(buttons, 1, 8);

            Controls.Add(t);
        }

        /// <summary>
        /// Validate required fields and, on success, create a new <see cref="Book"/> for the caller.
        /// </summary>
        private void ValidateAndFinish(object? sender, EventArgs e)
        {
            _err.Clear();
            bool ok = true;

            // Required: ISBN / Title / Author
            if (string.IsNullOrWhiteSpace(_isbn.Text)) { _err.SetError(_isbn, "ISBN is required."); ok = false; }
            if (string.IsNullOrWhiteSpace(_title.Text)) { _err.SetError(_title, "Title is required."); ok = false; }
            if (string.IsNullOrWhiteSpace(_author.Text)) { _err.SetError(_author, "Author is required."); ok = false; }
            if (!ok) return;

            // Build the result object for the caller (MainForm).
            ResultBook = new Book
            {
                Isbn = _isbn.Text.Trim(),
                Title = _title.Text.Trim(),
                Author = _author.Text.Trim(),
                Genre = _genre.SelectedItem?.ToString() ?? "General",
                Year = (int)_year.Value,
                Quantity = (int)_qty.Value,
                AddedOn = _added.Value,
                CheckedOut = _out.Checked
            };

            DialogResult = DialogResult.OK;  // Caller will read ResultBook
            Close();
        }
    }
}
