using System.Drawing;
using System.IO;
using System.Windows.Forms;
using LibraryManagerProCleanV11.Models;

namespace LibraryManagerProCleanV11.Forms
{
    /// <summary>
    /// Allows the user to switch autosave on/off and choose the JSON file location.
    /// </summary>
    public class SettingsForm : Form
    {
        private readonly AppSettings _settings;

        // UI elements are fields so we can read out values on OK.
        private CheckBox _chk = new CheckBox();
        private TextBox _txt = new TextBox();
        private Button _browse = new Button();
        private Button _ok = new Button();
        private Button _cancel = new Button();

        /// <summary>Create the settings dialog bound to the supplied <see cref="AppSettings"/>.</summary>
        public SettingsForm(AppSettings s)
        {
            _settings = s;
            Text = "Settings";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(600, 220);
            Init();
        }

        /// <summary>Build out the layout and wire up events.</summary>
        private void Init()
        {
            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 3, Padding = new Padding(12) };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));

            var l1 = new Label { Text = "Enable Autosave:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            _chk.Checked = _settings.AutoSave;

            var l2 = new Label { Text = "JSON Data File:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            _txt.Text = _settings.DataPath; _txt.Dock = DockStyle.Fill;

            // File picker: user chooses a new JSON file path (we create it on save).
            _browse.Text = "Browse..."; _browse.Dock = DockStyle.Fill;
            _browse.Click += (s,e) => {
                using var sfd = new SaveFileDialog { Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*", FileName = System.IO.Path.GetFileName(_txt.Text), InitialDirectory = System.IO.Path.GetDirectoryName(_txt.Text) };
                if (sfd.ShowDialog() == DialogResult.OK) _txt.Text = sfd.FileName;
            };

            // OK writes back to the supplied AppSettings instance.
            _ok.Text = "OK"; _ok.Dock = DockStyle.Fill;
            _ok.Click += (s,e) => { _settings.AutoSave = _chk.Checked; _settings.DataPath = _txt.Text; DialogResult = DialogResult.OK; Close(); };

            _cancel.Text = "Cancel"; _cancel.Dock = DockStyle.Fill;
            _cancel.Click += (s,e) => Close();

            t.Controls.Add(l1,0,0); t.Controls.Add(_chk,1,0);
            t.Controls.Add(l2,0,1); t.Controls.Add(_txt,1,1); t.Controls.Add(_browse,2,1);
            t.Controls.Add(_ok,1,2); t.Controls.Add(_cancel,2,2);
            Controls.Add(t);
        }
    }
}
