using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using LibraryManagerProCleanV11.Models;

namespace LibraryManagerProCleanV11.Forms
{
    /// <summary>
    /// Wizard-like dialog to choose a member and a book, then create a loan.
    /// </summary>
    public class IssueLoanDialog : Form
    {
        /// <summary>The newly created loan on success, else null.</summary>
        public Loan? ResultLoan { get; private set; }

        private readonly List<Member> _members;
        private readonly List<Book> _books;
        private readonly List<Loan> _loans;

        // Basic input controls
        private ComboBox _member = new ComboBox();
        private ComboBox _book = new ComboBox();
        private DateTimePicker _due = new DateTimePicker();
        private Button _ok = new Button();
        private Button _cancel = new Button();
        private Label _avail = new Label();   // shows copies available

        /// <summary>Supply in-memory lists so the dialog can validate availability.</summary>
        public IssueLoanDialog(List<Member> members, List<Book> books, List<Loan> loans)
        {
            _members = members; _books = books; _loans = loans;
            Text = "Issue Loan";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(620, 260);
            Init();
        }

        /// <summary>Build the UI and wire up events.</summary>
        private void Init()
        {
            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 5, Padding = new Padding(12) };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));

            // Members: bind to list of (Id, Name) so we can recover Id later.
            _member.DropDownStyle = ComboBoxStyle.DropDownList;
            _member.DataSource = _members.Select(m => new { m.Id, Name = m.FullName }).ToList();
            _member.DisplayMember = "Name";
            _member.ValueMember = "Id";

            // Books: bind to list of (Isbn, Label) where Label is human friendly.
            _book.DropDownStyle = ComboBoxStyle.DropDownList;
            _book.DataSource = _books.Select(b => new { b.Isbn, Label = b.Title + " (" + b.Isbn + ")" }).ToList();
            _book.DisplayMember = "Label";
            _book.ValueMember = "Isbn";
            _book.SelectedIndexChanged += (s,e)=>UpdateAvail(); // update availability when book changes

            _due.Format = DateTimePickerFormat.Short;
            _due.Value = DateTime.Now.AddDays(14);

            _ok.Text = "OK"; _ok.Click += (s,e)=>ValidateAndFinish();  // validate then emit ResultLoan
            _cancel.Text = "Cancel"; _cancel.Click += (s,e)=>Close();

            void Row(string label, Control c, int r)
            {
                t.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, r);
                c.Dock = DockStyle.Fill; t.Controls.Add(c, 1, r);
            }

            Row("Member:", _member, 0);
            Row("Book:", _book, 1);
            Row("Available:", _avail, 2);
            Row("Due Date:", _due, 3);

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            buttons.Controls.Add(_ok); buttons.Controls.Add(_cancel);
            t.Controls.Add(buttons, 1, 4);

            Controls.Add(t);
            UpdateAvail();   // initialize availability label
        }

        /// <summary>
        /// Compute available copies = Quantity - active (not yet returned) loans.
        /// </summary>
        private void UpdateAvail()
        {
            var isbn = _book.SelectedValue?.ToString() ?? "";
            var book = _books.FirstOrDefault(b => b.Isbn == isbn);
            if (book == null) { _avail.Text = "0"; return; }
            int active = _loans.Count(l => l.Isbn == isbn && !l.ReturnedDate.HasValue);
            int avail = Math.Max(0, book.Quantity - active);
            _avail.Text = avail.ToString();
        }

        /// <summary>
        /// Validate required selections and create a <see cref="Loan"/> if the book is available.
        /// </summary>
        private void ValidateAndFinish()
        {
            if (_member.SelectedValue == null || _book.SelectedValue == null)
            {
                MessageBox.Show("Select a member and a book.", "Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var isbn = _book.SelectedValue.ToString();
            var book = _books.FirstOrDefault(b => b.Isbn == isbn);
            if (book == null) { MessageBox.Show("Invalid book.", "Error"); return; }

            int active = _loans.Count(l => l.Isbn == isbn && !l.ReturnedDate.HasValue);
            if (book.Quantity - active <= 0)
            {
                MessageBox.Show("No available copies.", "Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            ResultLoan = new Loan
            {
                MemberId = _member.SelectedValue.ToString(),
                Isbn = isbn,
                LoanDate = DateTime.Now,
                DueDate = _due.Value,
                ReturnedDate = null
            };

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
