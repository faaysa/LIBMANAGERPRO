using System;
using System.IO;

namespace LibraryManagerProCleanV11.Models
{
    /// <summary>
    /// User-level preferences (autosave and where to store JSON data).
    /// </summary>
    public class AppSettings
    {
        /// <summary>When true, we save to JSON automatically after each mutation.</summary>
        public bool AutoSave { get; set; } = true;

        /// <summary>Absolute path to the JSON file that persists <see cref="LibraryData"/>.</summary>
        public string DataPath { get; set; } = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "LibraryManagerProCleanV11",
            "library.json");
    }
}
