using System;

namespace LibraryManagerProCleanV11.Models
{
    /// <summary>
    /// A loan ties one member to one book (by ISBN) for a period of time.
    /// </summary>
    public class Loan
    {
        /// <summary>Unique loan id (not shown in UI, but used for selection/deletion).</summary>
        public string Id { get; set; } = Guid.NewGuid().ToString("N");

        /// <summary>Foreign key to <see cref="Member.Id"/>.</summary>
        public string MemberId { get; set; } = string.Empty;

        /// <summary>Foreign key to <see cref="Book.Isbn"/>.</summary>
        public string Isbn { get; set; } = string.Empty;

        /// <summary>UTC-local timestamp when the loan was created.</summary>
        public DateTime LoanDate { get; set; } = DateTime.Now;

        /// <summary>Due date for returning the book.</summary>
        public DateTime DueDate { get; set; } = DateTime.Now.AddDays(14);

        /// <summary>Null until returned; set to the moment of return.</summary>
        public DateTime? ReturnedDate { get; set; } = null;

        /// <summary>Computed display status for the UI grids and reports.</summary>
        public string Status => ReturnedDate.HasValue ? "Returned" : (DateTime.Now > DueDate ? "Overdue" : "On Loan");
    }
}
