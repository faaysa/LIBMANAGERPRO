using System.Collections.Generic;

namespace LibraryManagerProCleanV11.Models
{
    /// <summary>
    /// Root container for all app state that we serialize to disk.
    /// </summary>
    public class LibraryData
    {
        /// <summary>List of books in the catalog.</summary>
        public List<Book> Books { get; set; } = new List<Book>();

        /// <summary>List of registered members.</summary>
        public List<Member> Members { get; set; } = new List<Member>();

        /// <summary>List of historical and active loans.</summary>
        public List<Loan> Loans { get; set; } = new List<Loan>();
    }
}
