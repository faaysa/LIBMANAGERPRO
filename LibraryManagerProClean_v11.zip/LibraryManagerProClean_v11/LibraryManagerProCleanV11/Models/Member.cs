using System;

namespace LibraryManagerProCleanV11.Models
{
    /// <summary>
    /// Domain model representing a library member who can borrow books.
    /// </summary>
    public class Member
    {
        /// <summary>Stable unique identifier for cross-referencing with loans.</summary>
        public string Id { get; set; } = Guid.NewGuid().ToString("N");

        /// <summary>Full name for display and search.</summary>
        public string FullName { get; set; } = string.Empty;

        /// <summary>Email address (optional) used for contact or exports.</summary>
        public string Email { get; set; } = string.Empty;

        /// <summary>Phone number (optional) used for contact or exports.</summary>
        public string Phone { get; set; } = string.Empty;

        /// <summary>Date the member joined the library.</summary>
        public DateTime JoinedOn { get; set; } = DateTime.Now;
    }
}
