using System;

namespace LibraryManagerProCleanV11.Models
{
    /// <summary>
    /// Domain model for a single book in the library's inventory.
    /// </summary>
    public class Book
    {
        /// <summary>Unique identifier for a title. We treat ISBN as the primary key in the UI.</summary>
        public string Isbn { get; set; } = string.Empty;

        /// <summary>Human-friendly title of the work.</summary>
        public string Title { get; set; } = string.Empty;

        /// <summary>Author or primary contributor.</summary>
        public string Author { get; set; } = string.Empty;

        /// <summary>Loose categorization for basic reporting (e.g., "Fiction").</summary>
        public string Genre { get; set; } = "General";

        /// <summary>Publication year, used in sorting and display.</summary>
        public int Year { get; set; } = DateTime.Now.Year;

        /// <summary>Total copies owned. Active loans reduce availability.</summary>
        public int Quantity { get; set; } = 1;

        /// <summary>When this record was created/added to the system.</summary>
        public DateTime AddedOn { get; set; } = DateTime.Now;

        /// <summary>
        /// Convenience flag for "any copy checked out right now".
        /// We recompute this when loans change.
        /// </summary>
        public bool CheckedOut { get; set; } = false;
    }
}
